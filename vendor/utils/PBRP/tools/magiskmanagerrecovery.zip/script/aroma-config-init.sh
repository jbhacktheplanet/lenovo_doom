#!/sbin/sh

cd /tmp/mmr/script/init

./gen-operations_edify.sh
./gen-magisksu_apps_edify.sh
./gen-module_backup_list_edify.sh

sync
